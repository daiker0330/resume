from flask import Flask, request
from subprocess import Popen, PIPE
import json

app = Flask(__name__, static_url_path='')

@app.route("/py/eval", methods=['GET', 'POST'])
def handle():
    if request.method == 'POST':

        # Implementation goes here.
        #
        # Both stdout and stderr should be captured.
        # {"stdout": "<output_from_stdout>", "stderr": "<output_from_stderr>"}

        ### BEGIN STUDENT CODE ###

        print("Enter Server POST Method")
        code = request.form['code']
        print("Code: " + code);
        proc = Popen(['python', '-c', code], stdout=PIPE, stderr=PIPE, shell=True)
        out, err = proc.communicate()
        exitcode = proc.returncode
        outString = out.decode('utf-8')
        errString = err.decode('utf-8')
        print("Output: " + outString)
        print("Error: " + errString)

        data = {}
        data['stdout'] = outString
        data['stderr'] = errString
        dataString = json.dumps(data)
        print("Json String: " + dataString)

        ### END STUDENT CODE ###
        return dataString
    else:
        return ''

if __name__ == '__main__':
    app.run(threaded=True, debug=True, host="0.0.0.0", port=6000)
