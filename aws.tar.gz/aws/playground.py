from flask import Flask, request
import requests

sqlServiceHostName = "http://localhost:8080";
pythonServiceHostName = ["http://localhost:6000", "http://localhost:6000"];
count = 0;

app = Flask(__name__, static_folder='site', static_url_path='')

@app.route("/", methods=['GET'])
def handle():
    return app.send_static_file("index.html")

@app.route("/sql", methods=['GET', 'POST'])
def handleSQL():
    if request.method == 'POST':
        operation = request.form['operation']
        query = request.form['query']
        
        print("Enter Playground SQL POST Method")
        print("Operation: " + operation)
        print ("Query: " + query)
        headers = {'Content-type': 'application/json'}

        relativePath = ''
        if operation == 'write': 
            relativePath = '/sql/write'
        else if operation == 'read':
            relativePath = '/sql/read'
        else: 
            return app.send_static_file("sql.html")

        r = requests.post(sqlServiceHostName + relativePath, headers=headers, 
            data = {'query': query})
        print("Response: " + r.text)
        return r.text
    else:
        return app.send_static_file("sql.html")

@app.route("/python", methods=['GET', 'POST'])
def handlePython():
    if request.method == 'POST':
        code = request.form['code']

        print("Enter Playground Python POST Method")
        print ("code: " + code)

        return requestURL(code)
    else:
        return app.send_static_file("python.html")

def requestURL(code=''):
    try: 
        global count
        select = count % len(pythonServiceHostName)
        count = count + 1
        print("Select url: " + pythonServiceHostName[select])
        r = requests.post(pythonServiceHostName[select] + '/py/eval', data = {'code':code})
        print("Response: " + r.text)
        return r.text
    except Exception as inst:
        print(type(inst))
        print(inst)
        return requestURL(code)

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=5000, threaded=True)
